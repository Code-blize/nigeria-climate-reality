# Outputs

Store small, shareable figures, tables, and metadata here. Confirm redistribution rights, record how each output was generated, include units and descriptive filenames, and avoid large rasters, temporary files, caches, and duplicate exports.
