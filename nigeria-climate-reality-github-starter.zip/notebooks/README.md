# Notebooks

Use this directory for exploratory or reproducible notebooks. Each notebook should state its research question, input datasets and exact versions, dependencies, assumptions, outputs, validation, and limitations. Keep large raw datasets out of Git unless their licences and size permit sharing.
