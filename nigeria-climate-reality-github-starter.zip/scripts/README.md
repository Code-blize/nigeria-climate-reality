# Scripts

Add reproducible processing scripts here only after verifying the actual workflow.

Possible future script names (proposals, not existing calculations):
- `01_prepare_temperature.py`
- `02_calculate_rainfall_variability.py`
- `03_prepare_flood_hazard.py`
- `04_prepare_population_layer.py`
- `05_validate_outputs.py`

Each script should document inputs, parameters, outputs, dependencies, CRS, NoData handling, and validation. Do not add placeholder scripts that imply results were calculated when they were not.
