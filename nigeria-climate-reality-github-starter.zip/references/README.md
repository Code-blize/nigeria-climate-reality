# References

Add complete citations for the exact dataset releases and any methods or papers used. Record access dates and licences.

Starting points:
- NASA POWER: https://power.larc.nasa.gov/
- CHIRPS: https://www.chc.ucsb.edu/data
- JRC Global River Flood Hazard Maps v2.1: https://developers.google.com/earth-engine/datasets/catalog/JRC_CEMS_GLOFAS_FloodHazard_v2_1
- WorldPop: https://www.worldpop.org/

These source portals are not substitutes for citing the exact product/version used.
